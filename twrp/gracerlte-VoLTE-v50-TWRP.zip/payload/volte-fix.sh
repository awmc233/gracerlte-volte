#!/system/bin/sh
# 首次开机后设置 VoLTE 相关属性与开关（幂等）
setprop persist.dbg.volte_avail_ovr 1
setprop persist.dbg.wfc_avail_ovr 1
setprop persist.dbg.allow_ims_off 1
setprop persist.radio.calls.on.ims 1
settings put global enhanced_4g_mode_enabled 1
settings put global hidden_api_policy 1
settings put global hidden_api_policy_p_apps 1
settings put global hidden_api_policy_pre_p_apps 1
